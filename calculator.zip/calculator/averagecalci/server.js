const express = require('express');
const axios = require('axios');

const app = express();
const PORT = 9876;
const WINDOW_SIZE = 10;
const NUMBER_APIS = {
    'p': 'http://20.244.56.144/test/primes',
    'f': 'http://20.244.56.144/test/fibo',
    'e': 'http://20.244.56.144/test/even',
    'r': 'http://20.244.56.144/test/rand'
};

let storedNumbers = [];

app.get('/numbers/:numberid', async (req, res) => {
    const numberid = req.params.numberid;
    if (!NUMBER_APIS[numberid]) {
        return res.status(400).json({ error: 'Invalid number ID' });
    }

    const previousState = [...storedNumbers];
    const newNumbers = await fetchNumbersFromAPI(NUMBER_APIS[numberid]);

    if (newNumbers.length) {
        updateWindow(newNumbers);
    }

    const currentState = [...storedNumbers];
    const average = calculateAverage(currentState);

    const response = {
        windowPrevState: previousState,
        windowCurrState: currentState,
        numbers: newNumbers,
        avg: average
    };

    res.json(response);
});

const fetchNumbersFromAPI = async (url) => {
    try {
        const response = await axios.get(url, { timeout: 500 });
        if (response.status === 200) {
            return response.data.numbers;
        }
    } catch (error) {
        console.error('Error fetching numbers:', error.message);
    }
    return [];
};

const updateWindow = (newNumbers) => {
    const uniqueNewNumbers = newNumbers.filter(num => !storedNumbers.includes(num));
    storedNumbers = [...storedNumbers, ...uniqueNewNumbers].slice(-WINDOW_SIZE);
};

const calculateAverage = (numbers) => {
    if (!numbers.length) return 0.0;
    const sum = numbers.reduce((acc, num) => acc + num, 0);
    return (sum / numbers.length).toFixed(2);
};

app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
