import React, { useState } from 'react';
import axios from 'axios';
import './App.css';

function App() {
    const [numberId, setNumberId] = useState('');
    const [responseData, setResponseData] = useState(null);
    const [error, setError] = useState(null);

    const handleInputChange = (event) => {
        setNumberId(event.target.value);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        setError(null);
        try {
            const response = await axios.get(`http://localhost:9876/numbers/${numberId}`);
            setResponseData(response.data);
        } catch (error) {
            setError('Error fetching data. Please try again.');
        }
    };

    return (
        <div className="App">
            <h1>Average Calculator</h1>
            <form onSubmit={handleSubmit}>
                <label>
                    Number ID (p, f, e, r):
                    <input type="text" value={numberId} onChange={handleInputChange} required />
                </label>
                <button type="submit">Fetch Numbers</button>
            </form>
            {error && <p className="error">{error}</p>}
            {responseData && (
                <div className="response">
                    <h2>Response</h2>
                    <pre>{JSON.stringify(responseData, null, 2)}</pre>
                </div>
            )}
        </div>
    );
}

export default App;
